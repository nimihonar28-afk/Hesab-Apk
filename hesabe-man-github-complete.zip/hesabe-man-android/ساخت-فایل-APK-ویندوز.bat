@echo off
chcp 65001 >nul
echo برای ساخت APK، ابتدا پروژه را در Android Studio باز و Sync کنید.
echo سپس از منوی Build گزینه Build APK(s) را انتخاب کنید.
echo خروجی معمولاً در app\build\outputs\apk\debug\app-debug.apk قرار می‌گیرد.
pause
