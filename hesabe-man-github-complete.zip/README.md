# حساب من (HesabeMan)

اپ اندروید «حساب من» با صفحه HTML داخلی که بدون اینترنت کار می‌کند.

ساخت APK: تب Actions ← آخرین اجرا ← Artifacts ← HesabeMan-APK
